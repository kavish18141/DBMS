Database-Management-Systems-Lab
Course Code-0705210506

Practical List

1.Draw an ER diagram and EER diagram and convert it into relational database and draw schema diagram.

2.Write and execute basic SQL query- create, alter, insert, update and delete. (instructor should frame appropriate problem definition).

3.Write and execute SQL functions- aggregate, numeric, date, string, and conversion.

4.Write and execute SQL queries- Operators (and, or, not, like, between, in)

5.Write and execute SQL queries- subqueries, joins.

6.Write and execute basic PL/SQL programs - simple program, condition statements and loops.

7.Write and execute PL/SQL function to print /return binary equivalent of decimal number.

8.Write and execute PL/SQL procedure to transfer fund from one account to another.

9.Write and execute triggers using PL/SQL.

10.Create and perform database operations using ODBC (Open Database Connectivity).
